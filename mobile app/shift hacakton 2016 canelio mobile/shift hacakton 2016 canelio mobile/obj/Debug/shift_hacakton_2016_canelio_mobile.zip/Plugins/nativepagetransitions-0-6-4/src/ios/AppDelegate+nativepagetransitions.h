#import "AppDelegate.h"

@interface AppDelegate (nativepagetransitions)

- (void)application:(UIApplication *)application willChangeStatusBarFrame:(CGRect)newStatusBarFrame;

@end